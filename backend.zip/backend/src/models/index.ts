export interface Pizza {
  id: string
  name: string
  ingredients: string[]
  price: number
}

export interface Ingredient {
  id: string
  name: string
  allergens: string[]
  availability: boolean
}

export interface Customer {
  id: string
  name: string
  address: string
  phone: string
}

export interface Order {
  id: string
  pizzas: string[] // Pizza IDs
  customerId: string
  status: "pending" | "preparing" | "ready" | "delivered" | "cancelled"
  totalPrice: number
  createdAt: Date
}

export interface Delivery {
  id: string
  date: Date
  orderId: string
  deliveryPerson: string
  status: "assigned" | "in_transit" | "delivered"
}
