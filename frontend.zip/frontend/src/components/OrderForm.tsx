"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { pizzaApi, customerApi, orderApi, type Pizza, type Customer } from "../utils/api"

const OrderForm: React.FC = () => {
  const [pizzas, setPizzas] = useState<Pizza[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [selectedPizzas, setSelectedPizzas] = useState<string[]>([])
  const [selectedCustomer, setSelectedCustomer] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const [pizzasResponse, customersResponse] = await Promise.all([pizzaApi.getAll(), customerApi.getAll()])
      setPizzas(pizzasResponse.data)
      setCustomers(customersResponse.data)
    } catch (err) {
      setError("Грешка при зареждане на данните")
    }
  }

  const calculateTotal = () => {
    return selectedPizzas.reduce((total, pizzaId) => {
      const pizza = pizzas.find((p) => p.id === pizzaId)
      return total + (pizza?.price || 0)
    }, 0)
  }

  const handlePizzaToggle = (pizzaId: string) => {
    setSelectedPizzas((prev) => (prev.includes(pizzaId) ? prev.filter((id) => id !== pizzaId) : [...prev, pizzaId]))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (selectedPizzas.length === 0) {
      setError("Моля изберете поне една пица")
      return
    }

    if (!selectedCustomer) {
      setError("Моля изберете клиент")
      return
    }

    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      await orderApi.create({
        pizzas: selectedPizzas,
        customerId: selectedCustomer,
        status: "pending",
        totalPrice: calculateTotal(),
      })

      setSuccess("Поръчката е създадена успешно!")
      setSelectedPizzas([])
      setSelectedCustomer("")
    } catch (err) {
      setError("Грешка при създаване на поръчката")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ backgroundColor: "white", border: "1px solid #ddd", borderRadius: "8px", padding: "2rem" }}>
      <h2>Нова поръчка</h2>
      {error && (
        <div
          style={{
            backgroundColor: "#f8d7da",
            color: "#721c24",
            padding: "1rem",
            borderRadius: "4px",
            marginBottom: "1rem",
          }}
        >
          {error}
        </div>
      )}
      {success && (
        <div
          style={{
            backgroundColor: "#d4edda",
            color: "#155724",
            padding: "1rem",
            borderRadius: "4px",
            marginBottom: "1rem",
          }}
        >
          {success}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: "1rem" }}>
          <label style={{ display: "block", marginBottom: "0.5rem", fontWeight: "bold" }}>Изберете клиент:</label>
          <select
            value={selectedCustomer}
            onChange={(e) => setSelectedCustomer(e.target.value)}
            required
            style={{ width: "100%", padding: "0.5rem", border: "1px solid #ddd", borderRadius: "4px" }}
          >
            <option value="">-- Изберете клиент --</option>
            {customers.map((customer) => (
              <option key={customer.id} value={customer.id}>
                {customer.name} - {customer.phone}
              </option>
            ))}
          </select>
        </div>

        <div style={{ marginBottom: "1rem" }}>
          <label style={{ display: "block", marginBottom: "0.5rem", fontWeight: "bold" }}>Изберете пици:</label>
          <div style={{ display: "grid", gap: "0.5rem", marginTop: "0.5rem" }}>
            {pizzas.map((pizza) => (
              <label key={pizza.id} style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                <input
                  type="checkbox"
                  checked={selectedPizzas.includes(pizza.id)}
                  onChange={() => handlePizzaToggle(pizza.id)}
                />
                <span>
                  {pizza.name} - {pizza.price.toFixed(2)} лв.
                </span>
              </label>
            ))}
          </div>
        </div>

        {selectedPizzas.length > 0 && (
          <div style={{ marginBottom: "1rem" }}>
            <strong>Обща сума: {calculateTotal().toFixed(2)} лв.</strong>
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          style={{
            padding: "0.75rem 1.5rem",
            backgroundColor: "#1976d2",
            color: "white",
            border: "none",
            borderRadius: "4px",
            cursor: "pointer",
          }}
        >
          {loading ? "Създаване..." : "Създай поръчка"}
        </button>
      </form>
    </div>
  )
}

export default OrderForm
