"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { orderApi, customerApi, pizzaApi, type Order, type Customer, type Pizza } from "../utils/api"

const OrderList: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [pizzas, setPizzas] = useState<Pizza[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      setLoading(true)
      const [ordersResponse, customersResponse, pizzasResponse] = await Promise.all([
        orderApi.getAll(),
        customerApi.getAll(),
        pizzaApi.getAll(),
      ])
      setOrders(ordersResponse.data)
      setCustomers(customersResponse.data)
      setPizzas(pizzasResponse.data)
    } catch (err) {
      setError("Грешка при зареждане на поръчките")
    } finally {
      setLoading(false)
    }
  }

  const getCustomerName = (customerId: string) => {
    const customer = customers.find((c) => c.id === customerId)
    return customer?.name || "Неизвестен клиент"
  }

  const getPizzaNames = (pizzaIds: string[]) => {
    return pizzaIds
      .map((id) => {
        const pizza = pizzas.find((p) => p.id === id)
        return pizza?.name || "Неизвестна пица"
      })
      .join(", ")
  }

  const getStatusText = (status: string) => {
    const statusMap: { [key: string]: string } = {
      pending: "Чакаща",
      preparing: "Приготвя се",
      ready: "Готова",
      delivered: "Доставена",
      cancelled: "Отказана",
    }
    return statusMap[status] || status
  }

  const getStatusColor = (status: string) => {
    const colorMap: { [key: string]: { bg: string; color: string } } = {
      pending: { bg: "#fff3cd", color: "#856404" },
      preparing: { bg: "#d1ecf1", color: "#0c5460" },
      ready: { bg: "#d4edda", color: "#155724" },
      delivered: { bg: "#d1ecf1", color: "#0c5460" },
      cancelled: { bg: "#f8d7da", color: "#721c24" },
    }
    return colorMap[status] || { bg: "#f8f9fa", color: "#495057" }
  }

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      await orderApi.update(orderId, { status: newStatus as any })
      loadData()
    } catch (err) {
      setError("Грешка при обновяване на статуса")
    }
  }

  if (loading) return <div style={{ textAlign: "center", padding: "2rem" }}>Зареждане...</div>
  if (error)
    return (
      <div style={{ backgroundColor: "#f8d7da", color: "#721c24", padding: "1rem", borderRadius: "4px" }}>{error}</div>
    )

  return (
    <div>
      <h2>Поръчки</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "1rem" }}>
        {orders.map((order) => {
          const statusStyle = getStatusColor(order.status)
          return (
            <div
              key={order.id}
              style={{ backgroundColor: "white", border: "1px solid #ddd", borderRadius: "8px", padding: "1rem" }}
            >
              <h3>Поръчка #{order.id}</h3>
              <p>
                <strong>Клиент:</strong> {getCustomerName(order.customerId)}
              </p>
              <p>
                <strong>Пици:</strong> {getPizzaNames(order.pizzas)}
              </p>
              <p>
                <strong>Обща сума:</strong>
                <span style={{ fontWeight: "bold", color: "#d32f2f", fontSize: "1.1rem" }}>
                  {order.totalPrice.toFixed(2)} лв.
                </span>
              </p>
              <p>
                <strong>Дата:</strong> {new Date(order.createdAt).toLocaleDateString("bg-BG")}
              </p>
              <p>
                <strong>Статус:</strong>
                <span
                  style={{
                    padding: "0.25rem 0.5rem",
                    borderRadius: "4px",
                    fontSize: "0.875rem",
                    fontWeight: "bold",
                    backgroundColor: statusStyle.bg,
                    color: statusStyle.color,
                    marginLeft: "0.5rem",
                  }}
                >
                  {getStatusText(order.status)}
                </span>
              </p>

              <div style={{ marginTop: "1rem", display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
                {order.status === "pending" && (
                  <button
                    style={{
                      padding: "0.5rem 1rem",
                      backgroundColor: "#1976d2",
                      color: "white",
                      border: "none",
                      borderRadius: "4px",
                      cursor: "pointer",
                    }}
                    onClick={() => updateOrderStatus(order.id, "preparing")}
                  >
                    Започни приготвяне
                  </button>
                )}
                {order.status === "preparing" && (
                  <button
                    style={{
                      padding: "0.5rem 1rem",
                      backgroundColor: "#388e3c",
                      color: "white",
                      border: "none",
                      borderRadius: "4px",
                      cursor: "pointer",
                    }}
                    onClick={() => updateOrderStatus(order.id, "ready")}
                  >
                    Готова за доставка
                  </button>
                )}
                {order.status === "ready" && (
                  <button
                    style={{
                      padding: "0.5rem 1rem",
                      backgroundColor: "#388e3c",
                      color: "white",
                      border: "none",
                      borderRadius: "4px",
                      cursor: "pointer",
                    }}
                    onClick={() => updateOrderStatus(order.id, "delivered")}
                  >
                    Доставена
                  </button>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default OrderList
