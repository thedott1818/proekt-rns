"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { customerApi, type Customer } from "../utils/api"

const CustomerForm: React.FC = () => {
  const [customers, setCustomers] = useState<Customer[]>([])
  const [formData, setFormData] = useState({
    name: "",
    address: "",
    phone: "",
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  useEffect(() => {
    loadCustomers()
  }, [])

  const loadCustomers = async () => {
    try {
      const response = await customerApi.getAll()
      setCustomers(response.data)
    } catch (err) {
      setError("Грешка при зареждане на клиентите")
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      await customerApi.create(formData)
      setSuccess("Клиентът е добавен успешно!")
      setFormData({ name: "", address: "", phone: "" })
      loadCustomers()
    } catch (err) {
      setError("Грешка при добавяне на клиента")
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  return (
    <div>
      <div
        style={{
          backgroundColor: "white",
          border: "1px solid #ddd",
          borderRadius: "8px",
          padding: "2rem",
          marginBottom: "2rem",
        }}
      >
        <h2>Добави нов клиент</h2>
        {error && (
          <div
            style={{
              backgroundColor: "#f8d7da",
              color: "#721c24",
              padding: "1rem",
              borderRadius: "4px",
              marginBottom: "1rem",
            }}
          >
            {error}
          </div>
        )}
        {success && (
          <div
            style={{
              backgroundColor: "#d4edda",
              color: "#155724",
              padding: "1rem",
              borderRadius: "4px",
              marginBottom: "1rem",
            }}
          >
            {success}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "1rem" }}>
            <label htmlFor="name" style={{ display: "block", marginBottom: "0.5rem", fontWeight: "bold" }}>
              Име:
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              style={{ width: "100%", padding: "0.5rem", border: "1px solid #ddd", borderRadius: "4px" }}
            />
          </div>

          <div style={{ marginBottom: "1rem" }}>
            <label htmlFor="address" style={{ display: "block", marginBottom: "0.5rem", fontWeight: "bold" }}>
              Адрес:
            </label>
            <input
              type="text"
              id="address"
              name="address"
              value={formData.address}
              onChange={handleChange}
              required
              style={{ width: "100%", padding: "0.5rem", border: "1px solid #ddd", borderRadius: "4px" }}
            />
          </div>

          <div style={{ marginBottom: "1rem" }}>
            <label htmlFor="phone" style={{ display: "block", marginBottom: "0.5rem", fontWeight: "bold" }}>
              Телефон:
            </label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              required
              style={{ width: "100%", padding: "0.5rem", border: "1px solid #ddd", borderRadius: "4px" }}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            style={{
              padding: "0.75rem 1.5rem",
              backgroundColor: "#1976d2",
              color: "white",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
          >
            {loading ? "Добавяне..." : "Добави клиент"}
          </button>
        </form>
      </div>

      <h2>Регистрирани клиенти</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "1rem" }}>
        {customers.map((customer) => (
          <div
            key={customer.id}
            style={{ backgroundColor: "white", border: "1px solid #ddd", borderRadius: "8px", padding: "1rem" }}
          >
            <h3>{customer.name}</h3>
            <p>
              <strong>Адрес:</strong> {customer.address}
            </p>
            <p>
              <strong>Телефон:</strong> {customer.phone}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default CustomerForm
