"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { pizzaApi, type Pizza } from "../utils/api"

const PizzaList: React.FC = () => {
  const [pizzas, setPizzas] = useState<Pizza[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [newName, setNewName] = useState("")
  const [newIngredients, setNewIngredients] = useState("")
  const [newPrice, setNewPrice] = useState("")

  useEffect(() => {
    loadPizzas()
  }, [])

  const loadPizzas = async () => {
    try {
      setLoading(true)
      const response = await pizzaApi.getAll()
      setPizzas(response.data)
    } catch (err) {
      setError("Грешка при зареждане на пиците")
    } finally {
      setLoading(false)
    }
  }

  const createPizza = async () => {
    if (!newName || !newIngredients || !newPrice) {
      alert("Попълнете всички полета.")
      return
    }

    const ingredientsArray = newIngredients.split(",").map((i) => i.trim())
    const priceNumber = parseFloat(newPrice)

    if (isNaN(priceNumber)) {
      alert("Цената трябва да е число.")
      return
    }

    try {
      const response = await pizzaApi.create({
        name: newName,
        ingredients: ingredientsArray,
        price: priceNumber,
      })
      setPizzas([...pizzas, response.data])
      setNewName("")
      setNewIngredients("")
      setNewPrice("")
    } catch (err) {
      alert("Грешка при създаване на пицата")
    }
  }

  const deletePizza = async (id: string) => {
    if (!confirm("Сигурни ли сте, че искате да изтриете тази пица?")) return
    try {
      await pizzaApi.delete(id)
      setPizzas(pizzas.filter((pizza) => pizza.id !== id))
    } catch (err) {
      alert("Грешка при изтриване на пицата")
    }
  }

  if (loading) return <div style={{ textAlign: "center", padding: "2rem" }}>Зареждане...</div>
  if (error)
    return (
      <div style={{ backgroundColor: "#f8d7da", color: "#721c24", padding: "1rem", borderRadius: "4px" }}>{error}</div>
    )

  return (
    <div>
      <h2>Налични пици</h2>

      {/* Форма за добавяне на нова пица */}
      <div style={{ marginBottom: "2rem", padding: "1rem", border: "1px solid #ccc", borderRadius: "8px" }}>
        <h3>Добави нова пица</h3>
        <input
          placeholder="Име"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          style={{ display: "block", marginBottom: "0.5rem", width: "100%", padding: "0.5rem" }}
        />
        <input
          placeholder="Съставки (разделени със запетая)"
          value={newIngredients}
          onChange={(e) => setNewIngredients(e.target.value)}
          style={{ display: "block", marginBottom: "0.5rem", width: "100%", padding: "0.5rem" }}
        />
        <input
          type="number"
          placeholder="Цена"
          value={newPrice}
          onChange={(e) => setNewPrice(e.target.value)}
          style={{ display: "block", marginBottom: "0.5rem", width: "100%", padding: "0.5rem" }}
        />
        <button onClick={createPizza} style={{ padding: "0.5rem 1rem", backgroundColor: "#4caf50", color: "white", border: "none", borderRadius: "4px" }}>
          Създай пица
        </button>
      </div>

      {/* Списък с пици */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "1rem" }}>
        {pizzas.map((pizza) => (
          <div
            key={pizza.id}
            style={{ backgroundColor: "white", border: "1px solid #ddd", borderRadius: "8px", padding: "1rem" }}
          >
            <h3>{pizza.name}</h3>
            <p>
              <strong>Съставки:</strong> {pizza.ingredients.join(", ")}
            </p>
            <p style={{ fontWeight: "bold", color: "#d32f2f", fontSize: "1.1rem" }}>{pizza.price.toFixed(2)} лв.</p>
            <button
              onClick={() => deletePizza(pizza.id)}
              style={{
                backgroundColor: "#e53935",
                color: "white",
                border: "none",
                padding: "0.5rem 1rem",
                borderRadius: "4px",
                cursor: "pointer",
                marginTop: "0.5rem",
              }}
            >
              Изтрий
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

export default PizzaList
