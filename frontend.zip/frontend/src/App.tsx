"use client"

import { useState } from "react"
import PizzaList from "./components/PizzaList"
import CustomerForm from "./components/CustomerForm"
import OrderForm from "./components/OrderForm"
import OrderList from "./components/OrderList"

type ActiveTab = "pizzas" | "customers" | "orders" | "new-order"

function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("pizzas")

  const renderContent = () => {
    switch (activeTab) {
      case "pizzas":
        return <PizzaList />
      case "customers":
        return <CustomerForm />
      case "orders":
        return <OrderList />
      case "new-order":
        return <OrderForm />
      default:
        return <PizzaList />
    }
  }

  return (
    <div>
      <header style={{ backgroundColor: "#d32f2f", color: "white", padding: "1rem", textAlign: "center" }}>
        <h1>🍕 Пицария - Онлайн поръчки</h1>
      </header>

      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "20px" }}>
        <nav style={{ display: "flex", justifyContent: "center", gap: "1rem", marginBottom: "2rem" }}>
          <button
            style={{
              padding: "0.5rem 1rem",
              backgroundColor: activeTab === "pizzas" ? "#0d47a1" : "#1976d2",
              color: "white",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
            onClick={() => setActiveTab("pizzas")}
          >
            Пици
          </button>
          <button
            style={{
              padding: "0.5rem 1rem",
              backgroundColor: activeTab === "customers" ? "#0d47a1" : "#1976d2",
              color: "white",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
            onClick={() => setActiveTab("customers")}
          >
            Клиенти
          </button>
          <button
            style={{
              padding: "0.5rem 1rem",
              backgroundColor: activeTab === "new-order" ? "#0d47a1" : "#1976d2",
              color: "white",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
            onClick={() => setActiveTab("new-order")}
          >
            Нова поръчка
          </button>
          <button
            style={{
              padding: "0.5rem 1rem",
              backgroundColor: activeTab === "orders" ? "#0d47a1" : "#1976d2",
              color: "white",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
            onClick={() => setActiveTab("orders")}
          >
            Поръчки
          </button>
        </nav>

        {renderContent()}
      </div>
    </div>
  )
}

export default App
