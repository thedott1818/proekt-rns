import axios from "axios"

const API_BASE_URL = "/api"

export interface Pizza {
  id: string
  name: string
  ingredients: string[]
  price: number
}

export interface Customer {
  id: string
  name: string
  address: string
  phone: string
}

export interface Order {
  id: string
  pizzas: string[]
  customerId: string
  status: "pending" | "preparing" | "ready" | "delivered" | "cancelled"
  totalPrice: number
  createdAt: string
}

// Pizza API
export const pizzaApi = {
  getAll: () => axios.get<Pizza[]>(`${API_BASE_URL}/pizzas`),
  getById: (id: string) => axios.get<Pizza>(`${API_BASE_URL}/pizzas/${id}`),
  create: (pizza: Omit<Pizza, "id">) => axios.post<Pizza>(`${API_BASE_URL}/pizzas`, pizza),
  update: (id: string, pizza: Partial<Pizza>) => axios.put<Pizza>(`${API_BASE_URL}/pizzas/${id}`, pizza),
  delete: (id: string) => axios.delete(`${API_BASE_URL}/pizzas/${id}`),
}

// Customer API
export const customerApi = {
  getAll: () => axios.get<Customer[]>(`${API_BASE_URL}/customers`),
  create: (customer: Omit<Customer, "id">) => axios.post<Customer>(`${API_BASE_URL}/customers`, customer),
}

// Order API
export const orderApi = {
  getAll: () => axios.get<Order[]>(`${API_BASE_URL}/orders`),
  create: (order: Omit<Order, "id" | "createdAt">) => axios.post<Order>(`${API_BASE_URL}/orders`, order),
  update: (id: string, order: Partial<Order>) => axios.put<Order>(`${API_BASE_URL}/orders/${id}`, order),
}
