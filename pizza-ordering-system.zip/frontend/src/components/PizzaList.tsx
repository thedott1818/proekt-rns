"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { pizzaApi, type Pizza } from "../utils/api"

const PizzaList: React.FC = () => {
  const [pizzas, setPizzas] = useState<Pizza[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadPizzas()
  }, [])

  const loadPizzas = async () => {
    try {
      setLoading(true)
      const response = await pizzaApi.getAll()
      setPizzas(response.data)
    } catch (err) {
      setError("Грешка при зареждане на пиците")
    } finally {
      setLoading(false)
    }
  }

  if (loading) return <div style={{ textAlign: "center", padding: "2rem" }}>Зареждане...</div>
  if (error)
    return (
      <div style={{ backgroundColor: "#f8d7da", color: "#721c24", padding: "1rem", borderRadius: "4px" }}>{error}</div>
    )

  return (
    <div>
      <h2>Налични пици</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "1rem" }}>
        {pizzas.map((pizza) => (
          <div
            key={pizza.id}
            style={{ backgroundColor: "white", border: "1px solid #ddd", borderRadius: "8px", padding: "1rem" }}
          >
            <h3>{pizza.name}</h3>
            <p>
              <strong>Съставки:</strong> {pizza.ingredients.join(", ")}
            </p>
            <p style={{ fontWeight: "bold", color: "#d32f2f", fontSize: "1.1rem" }}>{pizza.price.toFixed(2)} лв.</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default PizzaList
